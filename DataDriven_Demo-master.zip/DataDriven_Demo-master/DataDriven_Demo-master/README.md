### Coach Automation - Selenium Automation
---
#### System Requirement:

* JDK 1.8 
* Maven 3.3.3
* Eclipse or IDE of choice in case there is need to update the script. (optional)
* Set the system environment path of JAVA And Maven


## Execution On Firefox

1: Go to the project directory where pom.xml exists through cmd ot terminal , and write following commands to execute script

For Smoke Test , 

mvn clean verify -Dtestxml=smokeTest.xml